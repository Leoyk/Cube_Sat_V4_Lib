#include "commImu.h"
#include "Arduino.h"



RTIMU *imu;                                           // the IMU object
RTFusionRTQF fusion;                                  // the fusion object
RTIMUSettings settings;                               // the settings object




void imuInit(){
    imu = RTIMU::createIMU(&settings);                        // create the imu object

    imu->IMUInit();
  
    imu->getCalibrationValid();

    
    fusion.setSlerpPower(0.02);

    fusion.setGyroEnable(true);
    fusion.setAccelEnable(true);
    fusion.setCompassEnable(true);		
}



void imuData(float *AX,float *AY,float *AZ,float *GX,float *GY,float *GZ,float *MX,float *MY,float *MZ ,float *YAW ,float *PITCH ,float *ROLL)
{
  while (imu->IMURead()) {                              

    fusion.newIMUData(imu->getGyro(), imu->getAccel(), imu->getCompass(), imu->getTimestamp());

    
    *GX = imu->getGyro().x()*10;//dps
    *GY = imu->getGyro().y()*10;
    *GZ = imu->getGyro().z()*10;
    *AX = imu->getAccel().x()*10;//m/^s
    *AY = imu->getAccel().y()*10;
    *AZ = imu->getAccel().z()*10;
    *MX = imu->getCompass().x();
    *MY = imu->getCompass().y();
    *MZ = imu->getCompass().z();
    *ROLL = fusion.getFusionPose().x()*57.3;//degrees
    *PITCH = fusion.getFusionPose().y()*57.3;
    *YAW = fusion.getFusionPose().z()*57.3; 
  }	
	
}












//          RTMath::display("Gyro:", (RTVector3&)imu->getGyro());                // gyro data
//          RTMath::display("Accel:", (RTVector3&)imu->getAccel());              // accel data
//          RTMath::display("Mag:", (RTVector3&)imu->getCompass());              // compass data
//          RTMath::displayRollPitchYaw("Pose:", (RTVector3&)fusion.getFusionPose()); // fused output
//          Serial.println();      



////Gyro
//            Serial.print((imu->getGyro()).x());
//            Serial.print("|");      
//            Serial.print((imu->getGyro()).y()); 
//            Serial.print("|");       
//            Serial.print((imu->getGyro()).z());  
//            Serial.println("|");   

////Accel
//            Serial.print((imu->getAccel()).x());
//            Serial.print("|");      
//            Serial.print((imu->getAccel()).y()); 
//            Serial.print("|");       
//            Serial.print((imu->getAccel()).z());  
//            Serial.println("|");  

//Mag
//            Serial.print((imu->getCompass()).x());
//            Serial.print("|");      
//            Serial.print((imu->getCompass()).y()); 
//            Serial.print("|");       
//            Serial.print((imu->getCompass()).z());  
//            Serial.println("|");  


//ypr  
//            Serial.print((fusion.getFusionPose()).x()*57.3);
//            Serial.print("|");      
//            Serial.print((fusion.getFusionPose()).y()*57.3); 
//            Serial.print("|");       
//            Serial.print((fusion.getFusionPose()).z()*57.3);  
//            Serial.println("|");          
            
//            if (pressure->pressureRead(Pressure, Temperature)) {
//                Serial.print(", pressure: "); Serial.print(Pressure);
//                Serial.print(", temperature: "); Serial.print(Temperature);
//            }

