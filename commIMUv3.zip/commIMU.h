
#ifndef _COMMIMU_H
#define	_COMMIMU_H

#include <Wire.h>

void imuInit();

void getData(void);		


class IMU{
	public:
		float AX;
		float AY;
		float AZ;
		
		float GX;
		float GY;
		float GZ;
		
		float MX;
		float MY;
		float MZ;	
};

#endif