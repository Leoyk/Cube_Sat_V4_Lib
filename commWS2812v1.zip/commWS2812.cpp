
 #include "commWS2812.h"
 
 #include <Arduino.h>
 #include <String.h>
 



  #define PINR 2
  #define PINL 3  
  #define PINM 4
  
  
  #define BRIGHTL 40
  #define BRIGHTR 40
  int     BRIGHTM=40;
  
  
  
  
  
  
 
  Adafruit_NeoMatrix matrixL = Adafruit_NeoMatrix(8, 8, PINL,
  NEO_MATRIX_TOP     + NEO_MATRIX_LEFT +
  NEO_MATRIX_ROWS + NEO_MATRIX_PROGRESSIVE,
  NEO_GRB            + NEO_KHZ800);

  Adafruit_NeoPixel pixelsL = Adafruit_NeoPixel(64, PINL, NEO_GRB + NEO_KHZ800);


  Adafruit_NeoMatrix matrixR = Adafruit_NeoMatrix(8, 8, PINR,
  NEO_MATRIX_TOP     + NEO_MATRIX_LEFT +
  NEO_MATRIX_ROWS + NEO_MATRIX_PROGRESSIVE,
  NEO_GRB            + NEO_KHZ800);

  Adafruit_NeoPixel pixelsR = Adafruit_NeoPixel(64, PINR, NEO_GRB + NEO_KHZ800);


  Adafruit_NeoPixel pixelsM = Adafruit_NeoPixel(64, PINM, NEO_GRB + NEO_KHZ800);

  
  
  

void wsInit(){
  matrixL.begin();
  pixelsL.begin();
  pixelsL.setBrightness(BRIGHTL);
  
  matrixL.setTextWrap(false);
  matrixL.setBrightness(BRIGHTL);
  matrixL.setTextColor(matrixL.Color(0, 0, 0));  
  matrixL.show();  
  
  
  matrixR.begin();
  pixelsR.begin();
  pixelsR.setBrightness(BRIGHTR);
  
  matrixR.setTextWrap(false);
  matrixR.setBrightness(BRIGHTR);
  matrixR.setTextColor(matrixR.Color(0, 0, 0));  
  matrixR.show();  
  

  pixelsM.begin();
  pixelsM.setBrightness(BRIGHTM);
}


void clrPix(char lmr){
  if(lmr == 'L' || lmr == 'l')
    for(int i = 0;i < 64;i ++){
      pixelsL.setPixelColor(i,pixelsL.Color(0,0,0)); // Moderately bright green color.
      pixelsL.show(); // This sends the updated pixel color to the hardware.
    }
  else if(lmr == 'R' || lmr == 'r')
    for(int i = 0;i < 64;i ++){
      pixelsR.setPixelColor(i,pixelsR.Color(0,0,0)); // Moderately bright green color.
      pixelsR.show(); // This sends the updated pixel color to the hardware.
    }
  else if(lmr == 'M' || lmr == 'm')
    for(int i = 0;i < 64;i ++){
      pixelsM.setPixelColor(i,pixelsR.Color(0,0,0)); // Moderately bright green color.
      pixelsM.show(); // This sends the updated pixel color to the hardware.
    }
}

//低位左对齐
void setPix(char lmr,int hang,int lie,int r,int g,int b){

  if(lmr == 'L' || lmr == 'l'){
    for(int i = 0;i < 8;i ++){
      if(lie& (1 << i)){
         pixelsL.setPixelColor(hang * 8 + i, pixelsL.Color(r,g,b)); 
        }
      }
    pixelsL.show(); 
  }
  else if(lmr == 'R' || lmr == 'r'){
    for(int i = 0;i < 8;i ++){
      if(lie& (1 << i)){
         pixelsR.setPixelColor(hang * 8 + i, pixelsR.Color(r,g,b)); 
        }
      }
    pixelsR.show(); 
  }
  else if(lmr == 'M' || lmr == 'm'){
    for(int i = 0;i < 8;i ++){
      if(lie& (1 << i)){
         pixelsM.setPixelColor(hang * 8 + i, pixelsM.Color(r,g,b)); 
        }
      }
    pixelsM.show(); 
  }
 }

/*
功能：将字符串显示在点阵上
参数：要显示的字符串和rgb值
*/

bool showStrL(String a,int r,int g,int b){

static String ss = "";
static long x  = 0;
int flag = 1;
int sum = a.length();
  
  matrixL.setTextColor(matrixL.Color(r,g,b));
   
  if(flag == 0)
    x = matrixL.width();
  
  else{  
    ss = a;
    
      matrixL.fillScreen(0);
      matrixL.setCursor(x, 0);
      matrixL.print(a);  
      
  if(--x < -36) {
    x = matrixL.width();

      matrixL.show(); 
      return 1;
  }
      matrixL.show();  
  }
  return 0;
 }
bool showStrR(String a,int r,int g,int b){

static long x  = 0;
int flag = 1;
int sum = a.length();
  
  matrixR.setTextColor(matrixR.Color(r,g,b));
   
  if(flag == 0)
    x = matrixR.width();
  
  else{  
      matrixR.fillScreen(0);
      matrixR.setCursor(x, 0);
      matrixR.print(a);  
      
  if(--x < -36) {
    x = matrixR.width();

      matrixR.show(); 
      return 1;
  }
      matrixR.show();  
  }
  return 0;
 }

/* void showStr(String a,int r,int g,int b,int spe){

static unsigned long LM = 0;
static long x  = 0;
int flag = 1;
int sum = a.length();
  
  matrixL.setTextColor(matrixL.Color(r,g,b)); 

  x = matrixL.width();
  
  while(flag){  
    if(millis() - LM > spe){
      LM = millis();
      
      matrixL.fillScreen(0);
      matrixL.setCursor(x, 0);
      matrixL.print(a);  
      
  if(--x < -6*sum) {
    x = matrixL.width();
    flag = 0;
  }
      matrixL.show();  
    }
  }
 } */