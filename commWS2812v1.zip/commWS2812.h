#ifndef _COMMWS2812_H__
#define _COMMWS2812_H__

 #include <Adafruit_GFX.h>
 #include <Adafruit_NeoMatrix.h>
 #include <Adafruit_NeoPixel.h>
 

	 
	void wsInit();
	void clrPix(char lmr);
	void setPix(char lmr,int hang,int lie,int r,int g,int b);
	bool showStrL(String a,int r,int g,int b);
	bool showStrR(String a,int r,int g,int b);

#endif